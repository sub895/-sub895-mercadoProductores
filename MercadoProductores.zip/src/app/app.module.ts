import { NgModule } from '@angular/core';

import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';

import {HttpClientModule} from '@angular/common/http';

import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CabeceraComponent } from './modulos/cabecera/cabecera.component';
import { PieDePaginaComponent } from './modulos/pie-de-pagina/pie-de-pagina.component';
import { HomeComponent } from './paginas/home/home.component';
import { HomePanelCategoriasComponent } from './paginas/home/home-panel-categorias/home-panel-categorias.component';
import { CabeceraMobilComponent } from './modulos/cabecera-mobil/cabecera-mobil.component';
import { Error404Component } from './paginas/error404/error404.component';
import { ProductosComponent } from './paginas/productos/productos.component';
import { ProductoComponent } from './paginas/producto/producto.component';
import { BuscarComponent } from './paginas/buscar/buscar.component';
import { ProductosBreadcrumbComponent } from './paginas/productos/productos-breadcrumb/productos-breadcrumb.component';
import { ProductosMejoresVentasComponent } from './paginas/productos/productos-mejores-ventas/productos-mejores-ventas.component';
import { ProductosVitrinaComponent } from './paginas/productos/productos-vitrina/productos-vitrina.component';
import { IngresoComponent } from './paginas/ingreso/ingreso.component';
import { RegistroComponent } from './paginas/registro/registro.component';
import { CuentaComponent } from './paginas/cuenta/cuenta.component';
import { CuentaBreadcrumbComponent } from './paginas/cuenta/cuenta-breadcrumb/cuenta-breadcrumb.component';
import { CuentaPerfilComponent } from './paginas/cuenta/cuenta-perfil/cuenta-perfil.component';
import { SerUnVendedorComponent } from './paginas/ser-un-vendedor/ser-un-vendedor.component';

@NgModule({
  declarations: [
    AppComponent,
    CabeceraComponent,
    PieDePaginaComponent,
    HomeComponent,
    HomePanelCategoriasComponent,
    CabeceraMobilComponent,
    Error404Component,
    ProductosComponent,
    ProductoComponent,
    BuscarComponent,
    ProductosBreadcrumbComponent,
    ProductosMejoresVentasComponent,
    ProductosVitrinaComponent,
    IngresoComponent,
    RegistroComponent,
    CuentaComponent,
    CuentaBreadcrumbComponent,
    SerUnVendedorComponent,
    CuentaPerfilComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
