let domain;
let domain2;

import { environment } from '../environments/environment';

export let Ruta;
export let Server;
export let Email;

if(environment.production){

	domain = "";
	domain2 = domain;


}else{

	domain = 'http://localhost:4200/';
	domain2 = 'http://localhost:4200/src/';
	
}

Ruta = {

	url: domain+'assets/'

}

Server = {

	url: domain2+'assets/img/index.php?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg',
	delete: domain2+'assets/img/delete.php?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'
}


Email = {

	url: domain2+'assets/email/index.php?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'

}

export let Api = {

	url: 'https://marketplace-dcde8-default-rtdb.firebaseio.com/' 

}

export let Register = {

	url: 'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'
}


export let Login = {

	url: 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'
}


export let SendEmailVerification = {

	url: 'https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'

}


export let ConfirmEmailVerification = {

	url: 'https://identitytoolkit.googleapis.com/v1/accounts:update?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'

}


export let GetUserData = {

  url: 'https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'
  

   
}


export let SendPasswordResetEmail = {

 url: 'https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'

}


export let VerifyPasswordResetCode = {

	url: 'https://identitytoolkit.googleapis.com/v1/accounts:resetPassword?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'

}


export let ConfirmPasswordReset = {

	url:'https://identitytoolkit.googleapis.com/v1/accounts:resetPassword?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'

}


export let ChangePassword = {

	url:'https://identitytoolkit.googleapis.com/v1/accounts:update?key=AIzaSyCsIwpCFTvtCTq4-K37Rt9KoTTYKHIDhOg'
}

