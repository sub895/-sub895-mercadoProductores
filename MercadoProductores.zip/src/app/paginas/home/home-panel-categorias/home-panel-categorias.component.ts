import { Component, OnInit } from '@angular/core';
import { Ruta } from '../../../configuracion.js';
import { OwlCarouselConfig, Rating } from '../../../funciones.js';

declare var jQuery:any;
declare var $:any;

import { CategoriasService } from '../../../servicios/categorias.service';
import { SubCategoriasService } from '../../../servicios/sub-categorias.service';
import { ProductosService } from '../../../servicios/productos.service';


@Component({
  selector: 'app-home-panel-categorias',
  templateUrl: './home-panel-categorias.component.html',
  styleUrls: ['./home-panel-categorias.component.css']
})
export class HomePanelCategoriasComponent implements OnInit {

  ruta:string = Ruta.url;  
  categorias:any[] = [];
  cargando:boolean = false;
  render:boolean = true;

     constructor(private categoriasService: CategoriasService,
               private subCategoriasService: SubCategoriasService,
               private productosService: ProductosService) { }

  ngOnInit(): void {

    this.cargando = true;
    let getCategorias = [];

    this.categoriasService.getDatos()    
    .subscribe( resp => {
      
      let i;

      for(i in resp){

        getCategorias.push(resp[i])

      }

      getCategorias.sort(function(a,b){

        return(b.view - a.view)

      })

      getCategorias.forEach((categoria, index)=>{

        if(index < 6){

          this.categorias[index] = getCategorias[index];
          this.cargando = false;
        }

      })

    })
      
  }


  callback(indexes){

    if(this.render){

      this.render = false;

      let arraySubCategorias = [];
      let arrayProductos = [];
      let preloadSV = 0;


      this.categorias.forEach((categoria, index)=>{
        
        this.subCategoriasService.getFiltroDatos("categoria", categoria.nombre)
        .subscribe(resp=>{
          
          let i;

          for(i in resp){

            arraySubCategorias.push({

              "categoria": resp[i].categoria,
              "subcategoria": resp[i].nombre,
              "url": resp[i].url

            })
            
          }

          for(i in arraySubCategorias){

            if(categoria.nombre == arraySubCategorias[i].categoria){

              $(`[category-showcase='${categoria.nombre}']`).append(`

                <li><a href="productos/${arraySubCategorias[i].url}">${arraySubCategorias[i].subcategoria}</a></li>

              `)
            }
          }

        })

        this.productosService.getFiltroDatosConLimite("categoria", categoria.url, 6)
        .subscribe(resp=>{ 
          
          let i;

          for(i in resp){

            arrayProductos.push({

              "categoria": resp[i].categoria,
              "url": resp[i].url,
              "nombre": resp[i].nombre,
              "imagen": resp[i].imagen,
              "precio": resp[i].precio,
              "oferta": resp[i].oferta,
              "reseñas": resp[i].reseñas,
              "stock": resp[i].stock,
              "slider_vertical": resp[i].slider_vertical

            })

          }

          for(i in arrayProductos){

            if(categoria.url ==  arrayProductos[i].categoria){

              let precio;
              let tipo;
              let valor;
              let oferta;
              let descuento = "";
              let fechaOferta;
              let hoy = new Date();

              

              if(arrayProductos[i].oferta != ""){

                fechaOferta = new Date(

                          parseInt(JSON.parse(arrayProductos[i].oferta)[2].split("-")[0]),
                          parseInt(JSON.parse(arrayProductos[i].oferta)[2].split("-")[1])-1,
                          parseInt(JSON.parse(arrayProductos[i].oferta)[2].split("-")[2])

                      )

                      if(hoy < fechaOferta){

                  tipo = JSON.parse(arrayProductos[i].oferta)[0];
                  valor = JSON.parse(arrayProductos[i].oferta)[1];

                  if(tipo == "Descuento"){
                    
                    oferta = (arrayProductos[i].precio - (arrayProductos[i].precio * valor/100)).toFixed(2)  
                  }

                  if(tipo == "Fijo"){

                    oferta = valor;
                    valor = Math.round(oferta*100/arrayProductos[i].precio);

                  }

                  descuento = `<div class="ps-product__badge">-${valor}%</div>`;

                  precio = `<p class="ps-product__price sale">S/${oferta} <del>S/${arrayProductos[i].precio} </del></p>`

                }else{

                  

                  precio = `<p class="ps-product__price">S/${arrayProductos[i].precio} </p>`
                }
              
              }else{

                

                precio = `<p class="ps-product__price">S/${arrayProductos[i].precio} </p>`
              }

              let totalVistas = 0;

              for(let f = 0; f < JSON.parse(arrayProductos[i].reseñas).length; f++){

                totalVistas += Number(JSON.parse(arrayProductos[i].reseñas)[f]["review"]);
                
              }


              let rating = Math.round(totalVistas/JSON.parse(arrayProductos[i].reseñas).length);


              /*=============================================
              Definimos si el producto tiene stock
              =============================================*/  


              if(arrayProductos[i].stock == 0){

                descuento = `<div class="ps-product__badge out-stock">Fuera de Stock</div>`;

              }

              $(`[category-pb='${arrayProductos[i].categoria}']`).append(`

                 <div class="ps-product ps-product--simple">

                            <div class="ps-product__thumbnail">

                              <a href="product/${arrayProductos[i].url}">

                                <img src="assets/img/productos/${arrayProductos[i].categoria}/${arrayProductos[i].imagen}" alt="">

                              </a>

                                ${descuento}

                            </div>

                            <div class="ps-product__container">

                                <div class="ps-product__content" data-mh="clothing">

                                  <a class="ps-product__title" href="product/${arrayProductos[i].url}">${arrayProductos[i].nombre}</a>

                                    <div class="ps-product__rating">

                                        <select class="ps-rating productRating" data-read-only="true">

                                        </select>

                                        <span>${rating}</span>

                                    </div>

                                    ${precio}

                                </div>

                            </div>

                        </div> 

                      `)

              let arrayRating = $(".productRating");

              for(let i = 0; i < arrayRating.length; i++){

                for(let f = 1; f <= 5; f++){
                
                  $(arrayRating[i]).append(

                    `<option value="2">${f}</option>`
                  )

                  if(rating == f){

                    $(arrayRating[i]).children('option').val(1)

                  }

                }
              
              }

              Rating.fnc();


              $(`[category-sl='${arrayProductos[i].categoria}']`).append(`

                <a href="product/${arrayProductos[i].url}">

                          <img src="assets/img/productos/${arrayProductos[i].categoria}/vertical/${arrayProductos[i].slider_vertical}" alt="">

                        </a>

              `)
              
              preloadSV++;

              if(preloadSV == (indexes+1)*6){

                $(`[category-sl]`).addClass('ps-carousel--product-box')
                $(`[category-sl]`).addClass('owl-slider')

                $(`[category-sl]`).owlCarousel({

                   items: 1,
                   autoplay: true,
                   autoplayTimeout: 7000,
                   loop: true,
                                 nav: true,
                                 margin: 0,
                                 dots: true,
                                 navSpeed: 500,
                                 dotsSpeed: 500,
                                 dragEndSpeed: 500,
                                 navText: ["<i class='icon-chevron-left'></i>", "<i class='icon-chevron-right'></i>"],

                });

              }

            }

          }

        })

      })

    }
  }

}
