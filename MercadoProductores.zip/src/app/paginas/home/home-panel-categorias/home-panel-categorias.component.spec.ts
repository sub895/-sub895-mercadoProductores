import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomePanelCategoriasComponent } from './home-panel-categorias.component';

describe('HomePanelCategoriasComponent', () => {
  let component: HomePanelCategoriasComponent;
  let fixture: ComponentFixture<HomePanelCategoriasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomePanelCategoriasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomePanelCategoriasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
