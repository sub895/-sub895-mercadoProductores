import { Component, OnInit } from '@angular/core';

import { CategoriasService } from '../../../servicios/categorias.service';
import { SubCategoriasService } from '../../../servicios/sub-categorias.service';

import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-productos-breadcrumb',
  templateUrl: './productos-breadcrumb.component.html',
  styleUrls: ['./productos-breadcrumb.component.css']
})
export class ProductosBreadcrumbComponent implements OnInit {

  breadcrumb:string = null;

    constructor(private categoriasService: CategoriasService,
              private subCategoriasService: SubCategoriasService,
              private activateRoute: ActivatedRoute) { }

    ngOnInit(): void {

  let params = this.activateRoute.snapshot.params["param"].split("&")[0];

  this.categoriasService.getFiltroDatos("url", params)
  .subscribe(resp1=>{

    if(Object.keys(resp1).length > 0){

      let i;

      for(i in resp1){

        this.breadcrumb = resp1[i].nombre;

        let id = Object.keys(resp1).toString();
        
        let value = {
          "vista": Number(resp1[i].vista+1)
        }
console.log(value);
        this.categoriasService.modificarDato(id, value)
        .subscribe(resp=>{})
  
      }

    }else{ 

      this.subCategoriasService.getFiltroDatos("url", params)
      .subscribe(resp2=>{
  
        let i;

        for(i in resp2){

          this.breadcrumb = resp2[i].nombre;

          let id = Object.keys(resp2).toString();
        
          let value = {
            "vista": Number(resp2[i].vista+1)
          }

          this.subCategoriasService.modificarDato(id, value)
          .subscribe(resp=>{})
          
        }

      })

    }
    
  })
  
  }

}
