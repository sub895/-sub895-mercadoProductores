import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductosBreadcrumbComponent } from './productos-breadcrumb.component';

describe('ProductosBreadcrumbComponent', () => {
  let component: ProductosBreadcrumbComponent;
  let fixture: ComponentFixture<ProductosBreadcrumbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductosBreadcrumbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductosBreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
