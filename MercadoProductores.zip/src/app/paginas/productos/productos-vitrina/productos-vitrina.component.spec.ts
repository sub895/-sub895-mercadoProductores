import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductosVitrinaComponent } from './productos-vitrina.component';

describe('ProductosVitrinaComponent', () => {
  let component: ProductosVitrinaComponent;
  let fixture: ComponentFixture<ProductosVitrinaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductosVitrinaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductosVitrinaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
