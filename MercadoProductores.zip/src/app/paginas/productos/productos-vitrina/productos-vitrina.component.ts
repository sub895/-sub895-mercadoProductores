import { Component, OnInit } from '@angular/core';
import { Ruta } from '../../../configuracion.js';
import { Rating,
       DinamicRating, 
       DinamicReviews, 
       DinamicPrice,
       Pagination,
       Select2Cofig,
       Tabs } from '../../../funciones.js';

import { ProductosService} from '../../../servicios/productos.service';

import { ActivatedRoute } from '@angular/router';

declare var jQuery:any;
declare var $:any;

@Component({
  selector: 'app-productos-vitrina',
  templateUrl: './productos-vitrina.component.html',
  styleUrls: ['./productos-vitrina.component.css']
})
export class ProductosVitrinaComponent implements OnInit {

  ruta:string = Ruta.url;
  productos:any[] = [];
  render:boolean = true;
  cargando:boolean = false;
  rating:any[] = [];
  resenias:any[] = [];
  precio:any[] = [];
  params:string = null;
  pagina;
  productoEncontrado:number = 0;
  rutaActual:string = null;
  totalPagina:number = 0;
  ordenar;
  ordenarElementos:any[] = [];
  ordenarValores:any[] = [];

    constructor(private productosService: ProductosService,
              private activateRoute: ActivatedRoute,
               ) { }

   ngOnInit(): void {

     this.cargando = true;


    this.params = this.activateRoute.snapshot.params["param"].split("&")[0];
    this.ordenar = this.activateRoute.snapshot.params["param"].split("&")[1];
    this.pagina = this.activateRoute.snapshot.params["param"].split("&")[2];


    if(Number.isInteger(Number(this.ordenar))){

      this.pagina = this.ordenar;
      this.ordenar = undefined;
    
    }

    if(this.ordenar == undefined){

      this.rutaActual = `productos/${this.params}`;
    
    }else{

      this.rutaActual = `productos/${this.params}&${this.ordenar}`;

    }
    
    this.productosService.getFiltroDatos("categoria", this.params)
    .subscribe(resp1=>{

      if(Object.keys(resp1).length > 0){
        
        this.productosFnc(resp1);
        
      }else{


        this.productosService.getFiltroDatos("sub_categoria", this.params)
        .subscribe(resp2=>{
    
          this.productosFnc(resp2);      
                  
        })

      }
      
    })

    }

    productosFnc(response){

      this.productos = []; 

      let i;
      let getProductos = [];
      let total = 0;

      for(i in response){

        total++;

      getProductos.push(response[i]);            
        
    }
  

    this.productoEncontrado = total;
    this.totalPagina =  Math.ceil(Number(this.productoEncontrado)/6);

    if(this.ordenar == undefined || this.ordenar == "first"){

      getProductos.sort(function (a, b) {
          return (b.fecha_creada - a.fecha_creada)
      })

      this.ordenarElementos = [

        "Sort by first",
        "Sort by latest",
        "Sort by popularity",
        "Sort by price: low to high",
        "Sort by price: high to low"
      ]

      this.ordenarValores = [

        "first",
        "latest",
        "popularity",
        "low",
        "high"
      ]

    }


    if(this.ordenar == "latest"){

      getProductos.sort(function (a, b) {
          return (a.fecha_creada - b.fecha_creada)
      })

      this.ordenarElementos = [

        "Sort by latest",
        "Sort by first",  
        "Sort by popularity",
        "Sort by price: low to high",
        "Sort by price: high to low"
      ]

      this.ordenarValores = [

        "latest",
        "first",
        "popularity",
        "low",
        "high"
      ]
      
    }


    if(this.ordenar == "popularity"){

      getProductos.sort(function (a, b) {
          return (b.vistas - a.vistas)
      })

      this.ordenarElementos = [

        "Sort by popularity",
        "Sort by first",
        "Sort by latest",          
        "Sort by price: low to high",
        "Sort by price: high to low"
      ]

      this.ordenarValores = [

        "popularity",
        "first",
        "latest",        
        "low",
        "high"
      ]
      
    }

    if(this.ordenar == "low"){

      getProductos.sort(function (a, b) {
          return (a.precio - b.precio)
      })

      this.ordenarElementos = [

        "Sort by price: low to high",      
        "Sort by first",
        "Sort by latest",          
        "Sort by popularity",
        "Sort by price: high to low"
      ]

      this.ordenarValores = [

        "low",
        "first",
        "latest",
        "popularity",
        "high"
      ]

      
    }

    if(this.ordenar == "high"){

      getProductos.sort(function (a, b) {
          return (b.precio - a.precio)
      })

      this.ordenarElementos = [

        "Sort by price: high to low",    
        "Sort by first",
        "Sort by latest",          
        "Sort by popularity",
        "Sort by price: low to high"  
        
      ]

      this.ordenarValores = [

        "high",
        "first",
        "latest",
        "popularity",
        "low"
        
      ]

      
    }


    getProductos.forEach((producto, index)=>{

      if(this.pagina == undefined){

        this.pagina = 1;
      }  

      let first = Number(index) + (this.pagina*6)-6; 
      let last = 6*this.pagina;

      if(first < last){

        if(getProductos[first] != undefined){

          this.productos.push(getProductos[first]);

          this.rating.push(DinamicRating.fnc(getProductos[first]));
          
          this.resenias.push(DinamicReviews.fnc(this.rating[index]));

          this.precio.push(DinamicPrice.fnc(getProductos[first]));

          this.cargando = false;

        }
      }

    })

    }


    callback(params){

      if(this.render){

        this.render = false;

        Rating.fnc();
        Pagination.fnc();
        Select2Cofig.fnc();
        Tabs.fnc(); 

      $(".ordenarElementos").change(function(){

        window.open(`productos/${params}&${$(this).val()}`, '_top')

      })
      }
    }


}
