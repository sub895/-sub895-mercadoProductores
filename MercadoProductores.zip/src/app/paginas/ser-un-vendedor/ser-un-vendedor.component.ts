import { Component, OnInit } from '@angular/core';
import { Ruta } from '../../configuracion.js';

@Component({
  selector: 'app-ser-un-vendedor',
  templateUrl: './ser-un-vendedor.component.html',
  styleUrls: ['./ser-un-vendedor.component.css']
})
export class SerUnVendedorComponent implements OnInit {

	ruta:string = Ruta.url;

	constructor() { }

	ngOnInit(): void {
	}

}
