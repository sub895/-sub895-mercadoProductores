import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BecomeAVendorComponent } from './ser-un-vendedor.component';

describe('SerUnVendedorComponent', () => {
  let component: SerUnVendedoromponent;
  let fixture: ComponentFixture<SerUnVendedorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SerUnVendedorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SerUnVendedorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
