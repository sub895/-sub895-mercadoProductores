import { Component, OnInit } from '@angular/core';

import  { NgForm } from '@angular/forms';

import { Sweetalert } from '../../funciones.js';

import { UsuariosModelo } from '../../modelos/usuarios.modelo';

import { UsuariosService  } from '../../servicios/usuarios.service';

import { ActivatedRoute } from '@angular/router';

declare var jQuery:any;
declare var $:any;

@Component({
  selector: 'app-ingreso',
  templateUrl: './ingreso.component.html',
  styleUrls: ['./ingreso.component.css']
})
export class IngresoComponent implements OnInit {


  user: UsuariosModelo;
  recordarme:boolean = false;

  constructor(private usuariosService: UsuariosService,
        private activatedRoute: ActivatedRoute) {

    this.user = new UsuariosModelo();

  }

  ngOnInit(): void {

    if(localStorage.getItem("recordarme") && localStorage.getItem("recordarme") == "si"){

      this.user.email = localStorage.getItem("email");
      this.recordarme = true;

    }

    (function() {
      'use strict';
      window.addEventListener('load', function() {
    var forms = document.getElementsByClassName('needs-validation');
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
    }, false);
    })();

    if(this.activatedRoute.snapshot.queryParams["oobCode"] != undefined &&
       this.activatedRoute.snapshot.queryParams["mode"] == "verifyEmail"){

      let body = {

        oobCode: this.activatedRoute.snapshot.queryParams["oobCode"]
      }

      this.usuariosService.confirmarEmailVerificacionFnc(body)
      .subscribe(resp=>{

        if(resp["emailVerified"]){

              this.usuariosService.getFiltroDato("email", resp["email"])
              .subscribe(resp=>{

                for(const i in resp){

                  let id = Object.keys(resp).toString();

                  let value = {

                    necesitaConfirmar: true
                  }

                  this.usuariosService.modificarDato(id, value)
                  .subscribe(resp=>{

                    if(resp["necesitaConfirmar"]){

                      Sweetalert.fnc("success", "¡Correo electrónico confirmado, iniciar sesión ahora!", "ingreso")
                    }

                  })

                }

              })

        }

      }, err =>{

        if(err.error.error.message == "INVALID_OOB_CODE"){

          Sweetalert.fnc("error", "El correo electrónico ya ha sido confirmado", "ingreso")  

        }

      
      })

    }  

    if(this.activatedRoute.snapshot.queryParams["oobCode"] != undefined &&
       this.activatedRoute.snapshot.queryParams["mode"] == "resetPassword"){

      let body = {

        oobCode: this.activatedRoute.snapshot.queryParams["oobCode"]
      }

      this.usuariosService.verifyPasswordResetCodeFnc(body)
      .subscribe(resp=>{

        if(resp["requestType"] == "PASSWORD_RESET"){

          $("#newPassword").modal()

        }

      })

    }
  }
    validate(input){

        let pattern;

        if($(input).attr("name") == "email"){
          
          pattern = /^[^@]+@[^@]+\.[a-zA-Z]{2,}$/;
        }

        if($(input).attr("name") == "password"){

          pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,}$/;
          
        }

        if(!pattern.test(input.value)){

          $(input).parent().addClass('was-validated')

          input.value = "";
        
        }

    }

    onSubmit(f: NgForm ){

      if(f.invalid ){

            return;

      }


        Sweetalert.fnc("loading", "Loading...", null)

       this.usuariosService.getFiltroDato("email", this.user.email) 
       .subscribe( resp1 =>{

         for(const i in resp1){

           if(resp1[i].necesitaConfirmar){

            
            this.user.returnSecureToken = true;

            this.usuariosService.ingresoAutorizar(this.user)
            .subscribe( resp2 => {

              let id = Object.keys(resp1).toString();

                let value = {

                  idToken: resp2["idToken"]
                }

                this.usuariosService.modificarDato(id, value)
                .subscribe(resp3=>{

                  if(resp3["idToken"] != ""){

                    console.log("resp3",resp3);

                    Sweetalert.fnc("close", null, null)
              
                    localStorage.setItem("idToken", resp3["idToken"]);

                    localStorage.setItem("email", resp2["email"]);

                    let today = new Date();

                    today.setSeconds(resp2["expiresIn"]);

                    localStorage.setItem("expiresIn", today.getTime().toString());

                    if(this.recordarme){

                      localStorage.setItem("recordarme", "si");
                    
                    }else{

                      localStorage.setItem("recordarme", "no");
                    }

                    window.open("cuenta", "_top");

                  }

                })

            }, err =>{

                Sweetalert.fnc("error", err.error.error.message, null)

              })

           }else{

             Sweetalert.fnc("error", 'Necesita confirmar su correo electrónico', null)

           }

         }

       })     

    }

    resetPassword(value){

      Sweetalert.fnc("loading", "Loading...", null);

      this.usuariosService.getFiltroDato("email", value)
    .subscribe(resp=>{

      if(Object.keys(resp).length > 0){  

          let body = {

            requestType: "PASSWORD_RESET",
            email: value

          }

          this.usuariosService.sendPasswordResetEmailFnc(body)
          .subscribe(resp=>{

            if(resp["email"] == value){

              Sweetalert.fnc("success", "Revise su correo electrónico para cambiar la contraseña", "ingreso")

            }

          })

        }else{

        Sweetalert.fnc("error", "El correo electrónico no existe en nuestra base de datos", null)

      }

    })

    }

    newPassword(value){

      if(value != ""){

        Sweetalert.fnc("loading", "Loading...", null)

        let body = {

          oobCode: this.activatedRoute.snapshot.queryParams["oobCode"],
          newPassword: value

        }

        this.usuariosService.confirmPasswordResetFnc(body)
        .subscribe(resp=>{

          if(resp["requestType"] == "PASSWORD_RESET"){

            Sweetalert.fnc("success", "Cambio de contraseña exitoso, inicie sesión ahora", "ingreso")

          }

        })

      }

    }
}
