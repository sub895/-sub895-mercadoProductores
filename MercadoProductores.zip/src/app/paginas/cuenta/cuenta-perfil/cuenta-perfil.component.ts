import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";

import { Ruta, Server } from '../../../configuracion.js';
import { Sweetalert, Tooltip } from '../../../funciones.js';

import { UsuariosService  } from '../../../servicios/usuarios.service';

import { ActivatedRoute } from '@angular/router';

declare var jQuery:any;
declare var $:any;

@Component({
  selector: 'app-cuenta-perfil',
  templateUrl: './cuenta-perfil.component.html',
  styleUrls: ['./cuenta-perfil.component.css']
})
export class CuentaPerfilComponent implements OnInit {

  ruta:string = Ruta.url;
  vendor:boolean = false;
  mostrarNombre:string;
  usuario:string;
  email:string;
  picture:string;
  id:string;
  metodo:boolean = false;
  preload:boolean = false;
  server:string = Server.url;
  image:File = null;
  accountUrl:string = null;
  store:any[] = [];
  ordersPending:number = 0;
  disputes:any[] = [];
  messages:any[] = [];

  constructor(private usuariosService: UsuariosService,
        private http: HttpClient,
        private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {


    this.preload = true;


    if(this.activatedRoute.snapshot.params["param"] != undefined){

      this.accountUrl = this.activatedRoute.snapshot.params["param"].split("&")[0];

    }

    this.usuariosService.authActivado().then(resp =>{

      if(resp){

        this.usuariosService.getFiltroDato("idToken", localStorage.getItem("idToken"))
        .subscribe(resp=>{

          this.id = Object.keys(resp).toString();

          for(const i in resp){

          
            this.mostrarNombre = resp[i].mostrarNombre;

            this.usuario = resp[i].usuario;

            this.email = resp[i].email;

            if(resp[i].picture != undefined){

              if(resp[i].metodo != "direct"){

                this.picture = resp[i].picture;
              
              }else{

                this.picture = `assets/img/users/${resp[i].usuario.toLowerCase()}/${resp[i].picture}`;
              }

            }else{

              this.picture = `assets/img/users/default/default.png`;
            }

            if(resp[i].metodo != "direct"){

              this.metodo = true;
            }

            this.preload = false; 
          }

        })

      }

    })

    Tooltip.fnc();

    (function() {
      'use strict';
      window.addEventListener('load', function() {
    var forms = document.getElementsByClassName('needs-validation');
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
    }, false);
    })();

 $(".custom-file-input").on("change", function() {
      var fileName = $(this).val().split("\\").pop();
      $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });

  }

   
    validate(input){

      let pattern;

      if($(input).attr("name") == "password"){

        pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,}$/;
        
      }

      if(!pattern.test(input.value)){

        $(input).parent().addClass('was-validated')

        input.value = "";
      
      }

    }


    newPassword(value){

      if(value != ""){

        Sweetalert.fnc("loading", "Cargando...", null)

        let body = {

          idToken: localStorage.getItem('idToken'),
          password: value,
          returnSecureToken: true

        }

        this.usuariosService.cambiarPasswordFnc(body)
        .subscribe(resp1=>{  

            let value = {

              idToken: resp1["idToken"]
            }

            this.usuariosService.modificarDato(this.id, value)
            .subscribe(resp2=>{


              localStorage.setItem("idToken", resp1["idToken"]);


              let today = new Date();

              today.setSeconds(resp1["expiresIn"]);

              localStorage.setItem("expiresIn", today.getTime().toString());

              Sweetalert.fnc("success", "Cambio de contraseña exitoso", "account")

            })

        }, err =>{

          Sweetalert.fnc("error", err.error.error.message, null)

        })

      }

    }


    validateImage(e){
      
      this.image = e.target.files[0];


        if(this.image["type"] !== "image/jpeg" && this.image["type"] !== "image/png"){

        Sweetalert.fnc("error", "La imagen debe estar en formato JPG o PNG.", null)

        return;

        }


        else if(this.image["size"] > 2000000){

          Sweetalert.fnc("error", "La imagen no debe pesar más de 2 MB", null)

        return;

        }

        else{

          let data = new FileReader();
          data.readAsDataURL(this.image);

            $(data).on("load", function(event){

              let ruta = event.target.result; 

              $(".changePicture").attr("src", ruta)     

            })

        }

    }


    uploadImage(){

      const formData = new FormData();

      formData.append('file', this.image);
      formData.append('folder', this.usuario);
      formData.append('ruta', 'users');
      formData.append('width', '200');
      formData.append('height', '200');

      this.http.post(this.server, formData)
      .subscribe(resp =>{
        
        if(resp["status"] == 200){

          let body = {

            picture: resp["result"]
          }

          this.usuariosService.modificarDato(this.id, body)
          .subscribe(resp=>{

            if(resp["picture"] != ""){

              Sweetalert.fnc("success", "¡Tu foto ha sido actualizada!", "account")
            }

          })

        }

      })

    }

}
