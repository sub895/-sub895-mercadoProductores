import { Component, OnInit } from '@angular/core';

import { UsuariosService  } from '../../servicios/usuarios.service';

@Component({
  selector: 'app-cuenta',
  templateUrl: './cuenta.component.html',
  styleUrls: ['./cuenta.component.css']
})
export class CuentaComponent implements OnInit {

    constructor(private usuariosService: UsuariosService) { }

    ngOnInit(): void {

       this.usuariosService.authActivado().then(resp =>{
         
         if(!resp){

           window.open("ingreso", "_top")

         }

       })

    }

}
