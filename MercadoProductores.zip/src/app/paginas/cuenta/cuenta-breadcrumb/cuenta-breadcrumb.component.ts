import { Component, OnInit } from '@angular/core';

import { UsuariosService  } from '../../../servicios/usuarios.service';

@Component({
  selector: 'app-cuenta-breadcrumb',
  templateUrl: './cuenta-breadcrumb.component.html',
  styleUrls: ['./cuenta-breadcrumb.component.css']
})
export class CuentaBreadcrumbComponent implements OnInit {

mostrarNombre:string;

  constructor(private usuariosService: UsuariosService) { }

  ngOnInit(): void {

    this.usuariosService.authActivado().then(resp =>{

      if(resp){

        this.usuariosService.getFiltroDato("idToken", localStorage.getItem("idToken"))
        .subscribe(resp=>{

          for(const i in resp){

            this.mostrarNombre = resp[i].mostrarNombre;

          }

        })

      }

    })
  }
  logout(){

    localStorage.removeItem('idToken');
      localStorage.removeItem('expiresIn');
      window.open('login', '_top')

  }

}
