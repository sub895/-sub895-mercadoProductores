import { Component, OnInit } from '@angular/core';

import  { NgForm } from '@angular/forms';

import { Capitalize, Sweetalert } from '../../funciones.js';

import { UsuariosModelo } from '../../modelos/usuarios.modelo';

import { UsuariosService  } from '../../servicios/usuarios.service';

declare var jQuery:any;
declare var $:any;

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {

  user: UsuariosModelo;

  constructor(private usuariosService: UsuariosService){ 

    this.user = new UsuariosModelo();
  }

  ngOnInit(): void {
    (function() {
      'use strict';
      window.addEventListener('load', function() {
        var forms = document.getElementsByClassName('needs-validation');
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
      }, false);
    })();
  
  }

  capitalize(input){

    input.value = Capitalize.fnc(input.value)

  }

  validate(input){

    let pattern;

    if($(input).attr("name") == "usuario"){

      pattern = /^[A-Za-z]{2,8}$/;

      input.value = input.value.toLowerCase();

      this.usuariosService.getFiltroDato("usuario", input.value)
      .subscribe(resp=>{
        
        if(Object.keys(resp).length > 0){

          $(input).parent().addClass('was-validated')

          input.value = "";

          Sweetalert.fnc("error", "Username already exists", null)

          return;
         
        }

      })

    }

    if($(input).attr("name") == "password"){

      pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,}$/;
      
    }

    if(!pattern.test(input.value)){

      $(input).parent().addClass('was-validated')

      input.value = "";
    
    }

  }

  onSubmit(f: NgForm ){
  
    if(f.invalid ){

      return;

    }

    Sweetalert.fnc("loading", "Loading...", null)

    console.log("user",this.user);
    
    this.user.returnSecureToken = true;

    this.usuariosService.registroAutorizar(this.user)
    .subscribe(resp=>{
      
      if(resp["email"] == this.user.email){

        let body = {

          requestType: "VERIFY_EMAIL",
          idToken: resp["idToken"]
        
        }

        this.usuariosService.enviarEmailVerificacionFnc(body)
        .subscribe(resp=>{
          
          if(resp["email"] == this.user.email){


            this.user.mostrarNombre = `${this.user.nombres } ${this.user.apellidos}`;
            this.user.metodo = "direct";
            this.user.necesitaConfirmar = false;
            this.user.usuario = this.user.usuario.toLowerCase();     
            this.usuariosService.registroBaseDeDatos(this.user)
            .subscribe(resp=>{
              
               Sweetalert.fnc("success", "Confirme su cuenta en su correo electrónico (comprobar el correo no deseado)", "login")

            })

          }

        })        

      }

    }, err =>{

      Sweetalert.fnc("error", err.error.error.message, null)

    })

  }

}
