export let OwlCarouselConfig = {

	fnc: function(){

		var target = $('.owl-slider');
        if (target.length > 0) {
            target.each(function() {
                var el = $(this),
                    dataAuto = el.data('owl-auto'),
                    dataLoop = el.data('owl-loop'),
                    dataSpeed = el.data('owl-speed'),
                    dataGap = el.data('owl-gap'),
                    dataNav = el.data('owl-nav'),
                    dataDots = el.data('owl-dots'),
                    dataAnimateIn = (el.data('owl-animate-in')) ? el.data('owl-animate-in') : '',
                    dataAnimateOut = (el.data('owl-animate-out')) ? el.data('owl-animate-out') : '',
                    dataDefaultItem = el.data('owl-item'),
                    dataItemXS = el.data('owl-item-xs'),
                    dataItemSM = el.data('owl-item-sm'),
                    dataItemMD = el.data('owl-item-md'),
                    dataItemLG = el.data('owl-item-lg'),
                    dataItemXL = el.data('owl-item-xl'),
                    dataNavLeft = (el.data('owl-nav-left')) ? el.data('owl-nav-left') : "<i class='icon-chevron-left'></i>",
                    dataNavRight = (el.data('owl-nav-right')) ? el.data('owl-nav-right') : "<i class='icon-chevron-right'></i>",
                    duration = el.data('owl-duration'),
                    datamouseDrag = (el.data('owl-mousedrag') == 'on') ? true : false;
                if (target.children('div, span, a, img, h1, h2, h3, h4, h5, h5').length >= 1) {
                    el.owlCarousel({
                        animateIn: dataAnimateIn,
                        animateOut: dataAnimateOut,
                        margin: dataGap,
                        autoplay: dataAuto,
                        autoplayTimeout: dataSpeed,
                        autoplayHoverPause: true,
                        loop: dataLoop,
                        nav: dataNav,
                        mouseDrag: datamouseDrag,
                        touchDrag: true,
                        autoplaySpeed: duration,
                        navSpeed: duration,
                        dotsSpeed: duration,
                        dragEndSpeed: duration,
                        navText: [dataNavLeft, dataNavRight],
                        dots: dataDots,
                        items: dataDefaultItem,
                        responsive: {
                            0: {
                                items: dataItemXS
                            },
                            480: {
                                items: dataItemSM
                            },
                            768: {
                                items: dataItemMD
                            },
                            992: {
                                items: dataItemLG
                            },
                            1200: {
                                items: dataItemXL
                            },
                            1680: {
                                items: dataDefaultItem
                            }
                        }
                    });
                }

            });
        }

	}

}
export let Rating = {

    fnc: function() {
        $('select.ps-rating').each(function() {
            var readOnly;
            if ($(this).attr('data-read-only') == 'true') {
                readOnly = true
            } else {
                readOnly = false;
            }
            $(this).barrating({
                theme: 'fontawesome-stars',
                readonly: readOnly,
                emptyValue: '0'
            });
        });
    }

}

export let CarouselNavigation = {

    fnc: function(){

        var prevBtn = $('.ps-carousel__prev'),
            nextBtn = $('.ps-carousel__next');
        prevBtn.on('click', function(e) {
            e.preventDefault();
            var target = $(this).attr('href');
            $(target).trigger('prev.owl.carousel', [1000]);
        });
        nextBtn.on('click', function(e) {
            e.preventDefault();
            var target = $(this).attr('href');
            $(target).trigger('next.owl.carousel', [1000]);
        });


    }

}

export let DinamicRating = {

    fnc: function(response){


        let totalReview = 0;
        let rating = 0;

        for(let i = 0; i < JSON.parse(response.reseñas).length; i++){

            totalReview += Number(JSON.parse(response.reseñas)[i]["review"]);

        }

        rating = Math.round(totalReview/JSON.parse(response.reseñas).length);

        return rating;

    }

}


export let DinamicReviews = {


     fnc: function(response){

        let reseñas = [];

        for(let r = 0; r < 5; r++){

            if(response < (r+1)){

                reseñas[r] = 2
            
            }else{

                reseñas[r] = 1
            }    
        }

        return reseñas;
    }

}

export let DinamicPrice = {

    fnc: function(response){
    
        let type;
        let value;
        let oferta;
        let precio;
        let disccount;
        let arrayPrice = [];
        let ofertaFecha;
        let today = new Date();


        if(response.oferta != ""){

            ofertaFecha = new Date(

                parseInt(JSON.parse(response.oferta)[2].split("-")[0]),
                parseInt(JSON.parse(response.oferta)[2].split("-")[1])-1,
                parseInt(JSON.parse(response.oferta)[2].split("-")[2])

            )

            if(today < ofertaFecha){

                type = JSON.parse(response.oferta)[0];
                value = JSON.parse(response.oferta)[1];

                if(type == "Disccount"){

                    oferta = (response.precio-(response.precio * value/100)).toFixed(2)    
                }    

                if(type == "Fixed"){

                    oferta = value;
                    value = Math.round(oferta*100/response.precio);

                }

                disccount = `<div class="ps-product__badge">-${value}%</div>`;

                precio = `<p class="ps-product__price sale">$<span class="end-price">${oferta}</span> <del>$${response.precio} </del></p>`;

            }else{

                precio = `<p class="ps-product__price">$<span class="end-price">${response.precio}</span></p>`; 
            }

        }else{

            precio = `<p class="ps-product__price">$<span class="end-price">${response.precio}</span></p>`;
        }


        if(response.stock == 0){

            disccount = `<div class="ps-product__badge out-stock">Fuera de Stock</div>`;

        }

        arrayPrice[0] = precio;
        arrayPrice[1] = disccount;

        return arrayPrice;
    }

}

export let Pagination = {

    fnc: function(){

        var target = $('.pagination');
        
        if (target.length > 0) {

            target.each(function() {
                
                var tg = $(this),
                    totalPages = tg.data('total-pages'),                
                    actualPage = tg.data('actual-page'),
                    currentRoute = tg.data('current-route');    
   
                tg.twbsPagination({
                    totalPages: totalPages,
                    startPage: actualPage,
                    visiblePages: 4,
                    first: "First",
                    last: "Last",
                    prev: '<i class="fas fa-angle-left"></i>',
                    next: '<i class="fas fa-angle-right"></i>'
                }).on("page", function(evt, page){

                     window.location.href = currentRoute+"&"+page;

                })
               

            })
        }

    }

}

export let Select2Cofig = {

    fnc: function(){

        $('select.ps-select').select2({
            placeholder: $(this).data('placeholder'),
            minimumResultsForSearch: -1
        });
    }

}

export let Tabs = {

    fnc: function() {
        $('.ps-tab-list  li > a ').on('click', function(e) {
            e.preventDefault();
            var target = $(this).attr('href');
            $(this).closest('li').siblings('li').removeClass('active');
            $(this).closest('li').addClass('active');
            $(target).addClass('active');
            $(target).siblings('.ps-tab').removeClass('active');
        });
        $('.ps-tab-list.owl-slider .owl-item a').on('click', function(e) {
            e.preventDefault();
            var target = $(this).attr('href');
            $(this).closest('.owl-item').siblings('.owl-item').removeClass('active');
            $(this).closest('.owl-item').addClass('active');
            $(target).addClass('active');
            $(target).siblings('.ps-tab').removeClass('active');
        });
    }

}

export let Capitalize = {

    fnc: function(value){

        value = value.toLowerCase();

        let names = value.split(' ');

        names = names.map( name => {

            return name[0].toUpperCase() + name.substr(1)

        })

        return names.join(' ');

    }

}


export let Sweetalert = {

    fnc:function(type, text, url){

        switch (type) {

            case "error":

            if(url == null){

                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: text
                }) 

            }else{

                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: text
                }).then((result) => {

                    if (result.value) { 

                        window.open(url, "_top")
                    }

                })

            } 

            break; 

            case "success":

            if(url == null){

                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: text
                }) 

            }else{

                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: text
                }).then((result) => {

                    if (result.value) { 

                        window.open(url, "_top")
                    }

                })

            } 

            break; 

            case "loading":

              Swal.fire({
                allowOutsideClick: false,
                icon: 'info',
                text:text
              })
              Swal.showLoading()

            break;

            case "html":

            Swal.fire({
                allowOutsideClick: false,
                title: 'Haga clic para continuar con el pago...',
                icon: 'info',
                html:text,
                showConfirmButton: false,
                showCancelButton: true,
                cancelButtonColor: '#d33'
            })

            break;

            case "close":

                Swal.close()

            break;

        }

       
    }

}

export let Tooltip = {

    fnc: function(){

        $('[data-toggle="tooltip"]').tooltip();
    }

}