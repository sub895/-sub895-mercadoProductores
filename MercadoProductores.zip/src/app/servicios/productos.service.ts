import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Api } from '../configuracion.js';


@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  private api:string = Api.url;

  constructor(private http:HttpClient ) { }

  getDatos(){

    return this.http.get(`${this.api}productos.json`);

  }

  getLimitarDatos(startAt:string, limitToFirst:number){

    return this.http.get(`${this.api}productos.json?orderBy="$key"&startAt="${startAt}"&limitToFirst=${limitToFirst}&print=pretty`);

  }

  getFiltroDatos(orderBy:string, equalTo:string){

    return this.http.get(`${this.api}productos.json?orderBy="${orderBy}"&equalTo="${equalTo}"&print=pretty`);

  }

  getFiltroDatosConLimite(orderBy:string, equalTo:string, limitToFirst:number){

    return this.http.get(`${this.api}productos.json?orderBy="${orderBy}"&equalTo="${equalTo}"&limitToFirst=${limitToFirst}&print=pretty`);

  }

  getBuscarDatos(orderBy:string, param:string){

    return this.http.get(`${this.api}productos.json?orderBy="${orderBy}"&startAt="${param}"&endAt="${param}\uf8ff"&print=pretty`);

  }

  modificarDato(id:string, valor:object){

    return this.http.patch(`${this.api}productos/${id}.json`,valor);

  }
}
