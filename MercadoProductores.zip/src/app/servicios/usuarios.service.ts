import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {Api, 
    Register, 
    Login, 
    SendEmailVerification, 
    ConfirmEmailVerification, 
    GetUserData,
    SendPasswordResetEmail,
    VerifyPasswordResetCode,
    ConfirmPasswordReset,
      ChangePassword} from '../configuracion.js';

import { UsuariosModelo } from '../modelos/usuarios.modelo';
import { ProductosService } from '../servicios/productos.service';

import { Sweetalert } from '../funciones.js';

declare var jQuery:any;
declare var $:any;

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  private api:string = Api.url;
  private register:string = Register.url;private login:string = Login.url;
  private sendEmailVerification:string = SendEmailVerification.url;
  private confirmEmailVerification:string = ConfirmEmailVerification.url;
  private getUserData:string = GetUserData.url;
  private sendPasswordResetEmail:string = SendPasswordResetEmail.url;
  private verifyPasswordResetCode:string = VerifyPasswordResetCode.url;
  private confirmPasswordReset:string = ConfirmPasswordReset.url;
  private changePassword:string = ChangePassword.url;
  

  constructor(private http:HttpClient,
                private productosService: ProductosService) { }
  
  registroAutorizar(usuario: UsuariosModelo){

    return this.http.post(`${this.register}`, usuario);

  }


  registroBaseDeDatos(usuario: UsuariosModelo){

    delete usuario.nombres;
    delete usuario.apellidos;
    delete usuario.password;
    delete usuario.returnSecureToken;

    return this.http.post(`${this.api}/usuarios.json`, usuario);

  }

    getFiltroDato(orderBy:string, equalTo:string){

      return this.http.get(`${this.api}usuarios.json?orderBy="${orderBy}"&equalTo="${equalTo}"&print=pretty`);

    }
  
    ingresoAutorizar(usuario: UsuariosModelo){

      return this.http.post(`${this.login}`, usuario);

    } 

    enviarEmailVerificacionFnc(body:object){

      return this.http.post(`${this.sendEmailVerification}`, body);

    }

    confirmarEmailVerificacionFnc(body:object){

      return this.http.post(`${this.confirmEmailVerification}`, body);

    }

    modificarDato(id:string, value:object){

    return this.http.patch(`${this.api}usuarios/${id}.json`,value);

  }


    authActivado(){  

      return new Promise(resolve=>{

        if(localStorage.getItem("idToken")){

          let body = {

            idToken: localStorage.getItem("idToken") 
          }
      
        this.http.post(`${this.getUserData}`, body)
        .subscribe(resp=>{  

            if(localStorage.getItem("expiresIn")){

              let expiresIn = Number(localStorage.getItem("expiresIn"));

              let expiresDate = new Date();
              expiresDate.setTime(expiresIn);

              if(expiresDate > new Date()){

                resolve(true)
              
              }else{

                localStorage.removeItem('idToken');
                  localStorage.removeItem('expiresIn');
                resolve(false)
              }

            }else{

              localStorage.removeItem('idToken');
              localStorage.removeItem('expiresIn');
              resolve(false)
            
            }


        },err =>{
          
          localStorage.removeItem('idToken');
          localStorage.removeItem('expiresIn');
          resolve(false)

        })

      }else{

        localStorage.removeItem('idToken');
            localStorage.removeItem('expiresIn');    
        resolve(false)  
      }

    })  

    }

    sendPasswordResetEmailFnc(body:object){

      return this.http.post(`${this.sendPasswordResetEmail}`, body)

    }

    verifyPasswordResetCodeFnc(body:object){

      return this.http.post(`${this.verifyPasswordResetCode}`, body)

    }


    confirmPasswordResetFnc(body:object){

      return this.http.post(`${this.confirmPasswordReset}`, body)

    }

    cambiarPasswordFnc(body:object){

      return this.http.post(`${this.changePassword}`, body)

    }

    getUniqueData(value:string){

      return this.http.get(`${this.api}usuarios/${value}.json`);
    }


  addWishlist(product:string){

      this.authActivado().then(resp =>{

      if(!resp){

        Sweetalert.fnc("error", "The usuario must be logged in", null)

        return;

      }else{

        this.getFiltroDato("idToken", localStorage.getItem("idToken"))
        .subscribe(resp=>{

          let id = Object.keys(resp).toString();

          for(const i in resp){
          

              if(resp[i].wishlist != undefined){

                let wishlist = JSON.parse(resp[i].wishlist);

                let length = 0;

                if(wishlist.length > 0){

                  wishlist.forEach((list, index)=>{

                      if(list == product){

                        length --
                      
                      }else{

                        length ++

                      }

                  })


                  if(length != wishlist.length){

                    Sweetalert.fnc("error", "Ya existe en tu lista de deseos", null);

                  }else{

                    wishlist.push(product);

                    let body = {

                      wishlist: JSON.stringify(wishlist)
                    }

                    this.modificarDato(id, body)
                    .subscribe(resp=>{

                      if(resp["wishlist"] != ""){

                        let totalWishlist = Number($(".totalWishlist").html());
                        
                        $(".totalWishlist").html(totalWishlist+1); 

                        Sweetalert.fnc("success","Producto agregado a la lista de deseos", null);
                      }

                    })

                  }

                }else{

                  wishlist.push(product);

                let body = {

                    wishlist: JSON.stringify(wishlist)
                  }

                  this.modificarDato(id, body)
                  .subscribe(resp=>{

                    if(resp["wishlist"] != ""){

                      let totalWishlist = Number($(".totalWishlist").html());
                        
                      $(".totalWishlist").html(totalWishlist+1); 

                      Sweetalert.fnc("success","Producto agregado a la lista de deseos", null);
                    }


                  })

                }

              }else{

                let body = {

                  wishlist: `["${product}"]`
                }

                this.modificarDato(id, body)
                .subscribe(resp=>{

                  if(resp["wishlist"] != ""){

                    let totalWishlist = Number($(".totalWishlist").html());
                        
                    $(".totalWishlist").html(totalWishlist+1); 

                    Sweetalert.fnc("success","Producto agregado a la lista de deseos", null);
                  }

                })

              }

            }

        })

      }

    })

  }
    addSoppingCart(item:object){

        this.productosService.getFiltroDatos("url", item["product"])
        .subscribe(resp=>{
            

            for(const i in resp){

                if(resp[i]["stock"] == 0){

                    Sweetalert.fnc("error", "Out of Stock", null);

                    return;
                }

                if(item["details"].length == 0){

                  if(resp[i].specification != ""){

                    let specification = JSON.parse(resp[i].specification);

                    item["details"] = `[{`;

                    for(const i in specification){

                      let property = Object.keys(specification[i]).toString();

                      item["details"] += `"${property}":"${specification[i][property][0]}",` 

                    }

                    item["details"] = item["details"].slice(0, -1);

                    item["details"] += `}]`;

                  }

                }

            }
    
        })

        if(localStorage.getItem("list")){

            let arrayList = JSON.parse(localStorage.getItem("list"));
            let count = 0;
            let index;

            for(const i in arrayList){
                
                if(arrayList[i].product == item["product"] &&
                   arrayList[i].details.toString() == item["details"].toString()){

                    count --
                    index = i;
                
                }else{

                    count ++
                }

            }

            if(count == arrayList.length){
                     
                arrayList.push(item);

            }else{

                arrayList[index].unit += item["unit"];

            }         

            localStorage.setItem("list", JSON.stringify(arrayList));

            Sweetalert.fnc("success", "Producto agregado al carrito de compras", item["url"])

        }else{

            let arrayList = [];

            arrayList.push(item);

            localStorage.setItem("list", JSON.stringify(arrayList));

            Sweetalert.fnc("success", "Producto agregado al carrito de compras", item["url"])

        }
    
    }
}
