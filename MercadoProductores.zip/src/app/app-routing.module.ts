import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './paginas/home/home.component';
import { ProductosComponent } from './paginas/productos/productos.component';
import { ProductoComponent } from './paginas/producto/producto.component';
import { BuscarComponent } from './paginas/buscar/buscar.component';
import { Error404Component } from './paginas/error404/error404.component';
import { IngresoComponent } from './paginas/ingreso/ingreso.component';
import { RegistroComponent } from './paginas/registro/registro.component';
import { CuentaComponent } from './paginas/cuenta/cuenta.component';
import { SerUnVendedorComponent } from './paginas/ser-un-vendedor/ser-un-vendedor.component';

import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [

  {path: '', component: HomeComponent },
  {path: 'productos/:param', component: ProductosComponent },
  {path: 'producto/:param', component: ProductoComponent },
  {path: 'buscar/:param', component: BuscarComponent },
  {path: 'ingreso', component: IngresoComponent },
  {path: 'registro', component: RegistroComponent },
  {path: 'cuenta', component: CuentaComponent, canActivate: [ AuthGuard ]},
  {path: 'cuenta/:param', component: CuentaComponent, canActivate: [ AuthGuard ]},
  {path: 'ser-un-vendedor', component: SerUnVendedorComponent},

 {path: '**', pathMatch:'full', component: Error404Component }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
