export class ProductosModelo{

	categoria:string;
	fecha_creada:any;
	tiempo_delivery:number;
	descripcion:string;
	detalles:string;
	feedback:any;
	galeria:string;
	imagen:string;
	nombre:string;
	oferta:string;
	precio:string;
	resenias:string;
	ventas:number;
	envio:string;
	especificacion:string;
	stock:number;
	tienda:string;
	sub_categoria:string;
	resumen:string;
	titulo_lista:string;
	vistas:number;

}