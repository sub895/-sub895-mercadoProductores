export class UsuariosModelo{

	nombres:string;
	apellidos:string;
	mostrarNombre:string;
	usuario:string;
	email:string;
	password:string;
	returnSecureToken:boolean;
	metodo:string;
	imagen:string;
	idToken:string;
	necesitaConfirmar:boolean;

}