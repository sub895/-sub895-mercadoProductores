export class TiendasModelo{

	sobre:string;
	resumen:string;
	direccion:string;
	cover:string;
	email:string;
	logo:string;
	telefono:string;
	productos:number;
	social:string;
	tienda:string;
	url:string;
	nombreusuario:string;

}