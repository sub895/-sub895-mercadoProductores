import { Component, OnInit } from '@angular/core';
import { Ruta } from '../../configuracion.js';
import { CategoriasService } from '../../servicios/categorias.service';
import { SubCategoriasService } from '../../servicios/sub-categorias.service';
import { UsuariosService } from '../../servicios/usuarios.service';
import { Router } from '@angular/router';

declare var jQuery:any;
declare var $:any;

@Component({
  selector: 'app-cabecera',
  templateUrl: './cabecera.component.html',
  styleUrls: ['./cabecera.component.css']
})
export class CabeceraComponent implements OnInit {

  ruta:string = Ruta.url;
  categorias:any[] = []
  arrayTituloLista:any[] = [];
  render:boolean = true;
  authValidado:boolean = false;
  imagen:string;
  wishlist:number = 0;
  shoppingCart:any[] = [];
  totalShoppingCart:number = 0;
  renderShopping:boolean = true;
  subTotal:string = `<h3>Sub Total:<strong class="subTotalHeader"><div class="spinner-border"></div></strong></h3>`;
  lang:boolean = false;

  constructor(private categoriasService: CategoriasService,
            private subCategoriasService: SubCategoriasService,
            private usuariosService: UsuariosService,
         ) {  }

  ngOnInit(): void {

    if(localStorage.getItem("yt-widget") == '{"lang":"es","active":true}'){

      this.lang = true;

    }  

    this.usuariosService.authActivado().then(resp =>{

      if(resp){

        this.authValidado = true;

        this.usuariosService.getFiltroDato("idToken", localStorage.getItem("idToken"))
        .subscribe(resp=>{

          for(const i in resp){

            if(resp[i].wishlist != undefined){

              this.wishlist = Number(JSON.parse(resp[i].wishlist).length)

            }

            if(resp[i].imagen != undefined){

              if(resp[i].method != "direct"){

                this.imagen = `<img src="${resp[i].imagen}" class="img-fluid rounded-circle ml-auto">`;
              
              }else{

                this.imagen = `<img src="assets/img/users/${resp[i].usuario.toLowerCase()}/${resp[i].imagen}" class="img-fluid rounded-circle ml-auto">`;
              }

            }else{

              this.imagen = `<i class="icon-user"></i>`;
            }

          }

        })
      }

    })

    this.categoriasService.getDatos()
    .subscribe(resp => { 
      
      let i;

      for(i in resp){

        this.categorias.push(resp[i]);

        this.arrayTituloLista.push(JSON.parse(resp[i].titulo_lista));
        
      }

    })

  
  callback(){

    if(this.render){

      this.render = false;
      let arraySubCategorias = [];
      
     
      this.arrayTituloLista.forEach(tituloLista =>{


        for(let i = 0; i < tituloLista.length; i++){


          
          this.subCategoriasService.getFiltroDatos("titulo_lista", tituloLista[i])
          .subscribe(resp =>{
            
            arraySubCategorias.push(resp);

            let f;
            let g;
            let arrayTituloNombre = [];

            for(f in arraySubCategorias){


              for(g in arraySubCategorias[f]){

                arrayTituloNombre.push({

                  "tituloLista": arraySubCategorias[f][g].titulo_lista,
                  "subcategoria": arraySubCategorias[f][g].nombre,
                  "url": arraySubCategorias[f][g].url,

                })

              }

            }

            for(f in arrayTituloNombre){

              if(tituloLista[i] == arrayTituloNombre[f].tituloLista){

                $(`[tituloLista='${tituloLista[i]}']`).append(

                  `<li>
                    <a href="productos/${arrayTituloNombre[f].url}">${arrayTituloNombre[f].subcategoria}</a>
                  </li>`

                )
            
              }

            }          

          })

        }      

      })
    }

  }

}
