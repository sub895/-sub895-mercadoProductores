import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraMobilComponent } from './cabecera-mobil.component';

describe('CabeceraMobilComponent', () => {
  let component: CabeceraMobilComponent;
  let fixture: ComponentFixture<CabeceraMobilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CabeceraMobilComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraMobilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
