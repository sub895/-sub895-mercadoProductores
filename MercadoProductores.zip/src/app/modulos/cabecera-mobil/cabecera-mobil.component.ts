import { Component, OnInit } from '@angular/core';
import { Ruta } from '../../configuracion.js';

import { CategoriasService } from '../../servicios/categorias.service';
import { SubCategoriasService } from '../../servicios/sub-categorias.service';
import { ProductosService } from '../../servicios/productos.service';
import { UsuariosService } from '../../servicios/usuarios.service';

import { Router } from '@angular/router';

declare var jQuery:any;
declare var $:any;

@Component({
  selector: 'app-cabecera-mobil',
  templateUrl: './cabecera-mobil.component.html',
  styleUrls: ['./cabecera-mobil.component.css']
})

export class CabeceraMobilComponent implements OnInit {

  ruta:string = Ruta.url;  
  categorias:any[] = [];
  render:boolean = true;
  categoriasLista:any[] = [];
  authValidado:boolean = false;
  imagen:string;
  shoppingCart:any[] = [];
  totalShoppingCart:number = 0;
  renderShopping:boolean = true;
  subTotal:string = `<h3>Sub Total:<strong class="subTotalHeader"><div class="spinner-border"></div></strong></h3>`;
  lang:boolean = false;

  constructor(private categoriasService: CategoriasService, 
        private subCategoriasService: SubCategoriasService,
        private productosService: ProductosService,
        private usuariosService: UsuariosService,
        private router:Router) { }

  ngOnInit(): void {

    if(localStorage.getItem("yt-widget") == '{"lang":"es","active":true}'){

      this.lang = true;

    }  

    this.usuariosService.authActivado().then(resp =>{

      if(resp){

        this.authValidado = true;

        this.usuariosService.getFiltroDato("idToken", localStorage.getItem("idToken"))
        .subscribe(resp=>{

          for(const i in resp){

            if(resp[i].imagen != undefined){

              if(resp[i].method != "direct"){

                this.imagen = `<img src="${resp[i].imagen}" class="img-fluid rounded-circle ml-auto">`;
              
              }else{

                this.imagen = `<img src="assets/img/users/${resp[i].usuario.toLowerCase()}/${resp[i].imagen}" class="img-fluid rounded-circle ml-auto">`;
              }

            }else{

              this.imagen = `<i class="icon-user"></i>`;
            }

          }

        })
      }

    })

    this.categoriasService.getDatos()
    .subscribe(resp => {
      
      let i;

      for(i in resp){

        this.categorias.push(resp[i]);



        this.categoriasLista.push(resp[i].nombre)

      }

    })


    $(document).on("click", ".sub-toggle", function(){

      $(this).parent().children('ul').toggle();

    })


  callback(){

    if(this.render){

      this.render = false;
      let arraySubCategorias = [];


      this.categoriasLista.forEach(categoria=>{


        this.subCategoriasService.getFiltroDatos("categoria", categoria)
        .subscribe(resp=>{
          

          let i;

          for(i in resp){

            arraySubCategorias.push({

              "categoria": resp[i].categoria,
              "subcategoria": resp[i].nombre,
              "url": resp[i].url

            })

          }



          for(i in arraySubCategorias){

            if(categoria == arraySubCategorias[i].categoria){
              

              $(`[categoria='${categoria}']`).append(

                `<li class="current-menu-item ">
                              <a href="productos/${arraySubCategorias[i].url}">${arraySubCategorias[i].subcategoria}</a>
                            </li>`

                        )


            }


          }


                      

        })

      })      
      
    }

  }
}
