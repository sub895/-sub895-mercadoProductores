import { Component, OnInit } from '@angular/core';
import { Ruta } from '../../configuracion.js';

declare var jQuery:any;
declare var $:any;

import { CategoriasService } from '../../servicios/categorias.service';
import { SubCategoriasService } from '../../servicios/sub-categorias.service';

@Component({
  selector: 'app-pie-de-pagina',
  templateUrl: './pie-de-pagina.component.html',
  styleUrls: ['./pie-de-pagina.component.css']
})
export class PieDePaginaComponent implements OnInit {


  ruta:string = Ruta.url;  
  categorias:object = null;
  render:boolean = true;
  categoriasLista:any[] = [];

  constructor(private categoriasService: CategoriasService, private subCategoriasService: SubCategoriasService) { }

  ngOnInit(): void {


    this.categoriasService.getDatos()
    .subscribe(resp => {
      
      this.categorias = resp;

      let i;

      for(i in resp){


        this.categoriasLista.push(resp[i].nombre)

      }

    })
  }

  callback(){

    if(this.render){

      this.render = false;

      let arraySubCategorias = [];


      this.categoriasLista.forEach(categoria=>{
        

        this.subCategoriasService.getFiltroDatos("categoria", categoria)
        .subscribe(resp=>{
          
          let i;

          for(i in resp){

            arraySubCategorias.push({

              "categoria": resp[i].categoria,
              "subcategoria": resp[i].nombre,
              "url": resp[i].url

            })

          }

          for(i in arraySubCategorias){

            if(categoria == arraySubCategorias[i].categoria){    

              $(`[category-footer='${categoria}']`).after(

                `<a href="products/${arraySubCategorias[i].url}">${arraySubCategorias[i].subcategoria}</a>`

                        )
            }


          }


                      

        })

      })      

    }

  }

}
